"""Review probes for tutorials/kandinsky_controlnet_depth_colab.ipynb (prefix KCD).

Run: python run_probes.py <worktree> <evidence_dir> [<python_for_repo_gates>]
CPU only. No model weights are downloaded or loaded. Direct-execution probes use the repository's own package code
(numpy + pillow only) on synthetic images; documented-evidence probes read the executed Kaggle outputs recorded for the
reviewed notebook blob. Writes results.json and source_manifest.json next to this script.
"""

from __future__ import annotations

import ast
import hashlib
import io
import json
import re
import subprocess
import sys
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
WT = Path(sys.argv[1]).resolve()
EVID = Path(sys.argv[2]).resolve()
GATE_PY = sys.argv[3] if len(sys.argv) > 3 else sys.executable
NB_PATH = WT / "tutorials" / "kandinsky_controlnet_depth_colab.ipynb"
STRICT_DEFAULT = EVID / "out-strict/dimer-nb2-kandinsky-controlnet-depth/v2/evidence"
STRICT_BYOD = EVID / "out-strict/dimer-nb2-kandinsky-controlnet-depth-byod/evidence"
results: dict[str, dict] = {}
inspected: list[Path] = []


def record(pid: str, basis: str, passed: bool | None, **detail) -> None:
    results[pid] = {"basis": basis, "pass": passed, **detail}
    print(pid, "PASS" if passed else ("INFO" if passed is None else "FAIL"), json.dumps(detail)[:300])


def git_blob(path: Path) -> str:
    data = path.read_bytes()
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()


def find_report(root: Path) -> Path:
    return next(root.rglob("kandinsky_controlnet_depth_evaluation_report.json"))


nb = json.loads(NB_PATH.read_text(encoding="utf-8"))
inspected.append(NB_PATH)
cells = nb["cells"]
src = ["".join(c["source"]) for c in cells]
md_text = "\n".join(s for s, c in zip(src, cells) if c["cell_type"] == "markdown")
all_text = "\n".join(src)

# P01 structure and hygiene
code = [i for i, c in enumerate(cells) if c["cell_type"] == "code"]
compile_errors = []
for i in code:
    try:
        compile(src[i], f"cell{i}", "exec")
    except SyntaxError as exc:
        compile_errors.append((i, str(exc)))
outputs = sum(len(cells[i].get("outputs", [])) for i in code)
counts = [cells[i].get("execution_count") for i in code if cells[i].get("execution_count") is not None]
meta = nb["metadata"]["dimer"]
record("P01_structure", "source inspection", not compile_errors and outputs == 0 and not counts,
       nbformat=f"{nb['nbformat']}.{nb['nbformat_minor']}", cells=len(cells), code_cells=len(code),
       compile_errors=compile_errors, persisted_outputs=outputs, execution_counts=counts,
       profile=meta["notebook_profile"], mode=meta["notebook_mode"], spec=meta["notebook_spec"])

# P02 reviewed blob equals the blob of the recorded hosted runs
blob = git_blob(NB_PATH)
summ = json.loads((STRICT_DEFAULT / "run_summary.json").read_text(encoding="utf-8"))
inspected.append(STRICT_DEFAULT / "run_summary.json")
record("P02_blob_matches_evidence", "documented execution evidence", blob == summ["identity"]["committed_blob"],
       notebook_blob=blob, evidence_blob=summ["identity"]["committed_blob"], evidence_commit=summ["identity"]["candidate_sha"],
       runner_ok=summ["runner"].get("ok"))

# P03 carrier parity: carried text hashes and equality with repository files
carrier = next(i for i in code if "CARRIED_FILES =" in src[i])
tree = ast.parse(src[carrier])
assigned = {t.targets[0].id: ast.literal_eval(t.value) for t in tree.body if isinstance(t, ast.Assign) and isinstance(t.targets[0], ast.Name) and t.targets[0].id in ("CARRIED_FILES", "CARRIED_HASHES")}
files, hashes = assigned["CARRIED_FILES"], assigned["CARRIED_HASHES"]
mism = []
for name, text in files.items():
    if hashlib.sha256(text.encode("utf-8")).hexdigest() != hashes[name]:
        mism.append(("hash", name))
for name, rel in json.loads(files["source.json"])["sources"].items():
    p = WT / rel
    inspected.append(p)
    if p.read_bytes().replace(b"\r\n", b"\n") != files[name].encode("utf-8"):
        mism.append(("repo", name))
record("P03_carrier_parity", "source inspection", not mism, carried=len(files), repo_files_compared=len(json.loads(files["source.json"])["sources"]), mismatches=mism)

# P04 isolated environment, no kernel install, no restart instruction
kernel_pip = [i for i in code if re.search(r"(?<!uv', ')\bpip install\b|-m pip|%pip|!pip", src[i])]
uv_cell = next(i for i in code if "UV_SHA256" in src[i])
restart_prose = [m.group(0) for m in re.finditer(r"[^.\n]*restart[^.\n]*", md_text) if "no restart" not in m.group(0).lower() and "no runtime restart" not in m.group(0).lower() and "never" not in m.group(0).lower()]
record("P04_isolated_env", "source inspection", not kernel_pip and "--require-hashes" in src[uv_cell] and "--managed-python" in src[uv_cell],
       kernel_pip_cells=kernel_pip, uv_cell=uv_cell, restart_sentences_not_negated=restart_prose)

# P05 KCD-M1: per-timestep loss direction, prose vs recorded result
rep = json.loads(find_report(STRICT_DEFAULT).read_text(encoding="utf-8"))
inspected.append(find_report(STRICT_DEFAULT))
by_t = {int(k): v for k, v in rep["frozen"]["test"]["by_timestep"].items()}
ts = sorted(by_t)
decreasing = all(by_t[a] > by_t[b] for a, b in zip(ts, ts[1:]))
claims = {
    "cell19_rising": "per-timestep loss rising with the noise level" in src[19],
    "cell21_highest_at_large": "highest at large timesteps" in src[21],
}
share_t100 = by_t[100] / (5 * rep["frozen"]["test"]["denoising_mse"])
record("P05_KCD-M1_timestep_direction", "documented execution evidence + source inspection", not (decreasing and any(claims.values())),
       frozen_test_by_timestep=by_t, adapted_test_by_timestep=rep["adapted"]["test"]["by_timestep"], strictly_decreasing=decreasing,
       ratio_t100_over_t900=round(by_t[100] / by_t[900], 1), share_of_mean_from_t100=round(share_t100, 3), prose_claims=claims,
       note="FAIL = the notebook states the opposite of the recorded per-timestep result")

# P06 KCD-m1: CLIP 'ceiling' and 'often it cannot' vs recorded results
rep_b = json.loads(find_report(STRICT_BYOD).read_text(encoding="utf-8"))
inspected.append(find_report(STRICT_BYOD))
rows = {}
for label, r in (("default", rep), ("byod", rep_b)):
    rows[label] = {"frozen_prompt_sim": r["frozen"]["clip"]["clip_prompt_similarity"], "adapted_prompt_sim": r["adapted"]["clip"]["clip_prompt_similarity"],
                   "real_photo_prompt_sim": r["real_photo_ceiling"]["clip_prompt_similarity"], "frozen_label_acc": r["frozen"]["clip"]["label_accuracy"],
                   "real_label_acc": r["real_photo_ceiling"]["label_accuracy"]}
exceeds = all(v["frozen_prompt_sim"] > v["real_photo_prompt_sim"] for v in rows.values())
record("P06_KCD-m1_clip_reference", "documented execution evidence + source inspection", not (exceeds and "the ceiling" in src[19]),
       rows=rows, calls_it_ceiling="the ceiling" in src[19], sample_answer_often_cannot="often it cannot" in src[21])

# P07 KCD-m2: split semantics and independence (direct execution, numpy + pillow, synthetic images)
sys.path.insert(0, str(WT / "src"))
from PIL import Image  # noqa: E402

from kandinsky_controlnet_depth_pipeline import load_byod_dataset, split_dataset  # noqa: E402

inspected += [WT / "src/kandinsky_controlnet_depth_pipeline/samples.py", WT / "src/kandinsky_controlnet_depth_pipeline/pipeline.py"]


def img(seed: int, size: int = 320, tweak: bool = False) -> Image.Image:
    import numpy as np
    arr = np.random.default_rng(seed).integers(0, 255, (size, size, 3), dtype=np.uint8)
    if tweak:
        arr[0, 0, 0] ^= 1
    return Image.fromarray(arr)


recs = [{"id": f"c{c}-{k}", "image": img(c * 10 + k), "caption": f"caption {c}"} for c in range(3) for k in range(5)]
recs.append({"id": "c0-near-dup", "image": img(0, tweak=True), "caption": "caption 0"})  # one-pixel variant of c0-0
sp = split_dataset(recs, seed=0)
caps = {name: sorted({r["caption"] for r in part}) for name, part in sp.items()}
where = {name: [r["id"] for r in part if r["id"] in ("c0-0", "c0-near-dup")] for name, part in sp.items()}
stratified_within_caption = caps["train"] == caps["test"] == ["caption 0", "caption 1", "caption 2"]
near_dup_kept = sum(len(v) for v in where.values()) == 2
independence_stated = bool(re.search(r"independen", all_text))
record("P07_KCD-m2_split_semantics", "direct execution (CPU, synthetic images) + source inspection", independence_stated,
       captions_per_split=caps, every_caption_in_train_and_test=stratified_within_caption, near_duplicate_pair_location=where,
       near_duplicate_accepted=near_dup_kept, independence_assumption_stated=independence_stated,
       hold_out_by_caption_phrase="Hold out by caption, not by image" in src[33])

# P08 KCD-m3: pretraining-overlap limitation (DAT9)
overlap_stated = bool(re.search(r"overlap|pretraining data|training data of|seen during (pre)?training", md_text, re.I))
record("P08_KCD-m3_DAT9", "source inspection", overlap_stated, overlap_statement_in_notebook=overlap_stated,
       sample="60 iNaturalist photographs (public web images)", scorer=rep["scorer"].get("id") if isinstance(rep.get("scorer"), dict) else rep.get("scorer"))

# P09 KCD-m4: stale timing status
rv = (WT / "docs/release-verification.md").read_text(encoding="utf-8")
tr = (WT / "tutorials/README.md").read_text(encoding="utf-8")
inspected += [WT / "docs/release-verification.md", WT / "tutorials/README.md"]
stale_nb = "has not yet been recorded" in src[0]
stale_readme = "not yet recorded for this revision" in tr
recorded = "1,156.2 s" in rv
record("P09_KCD-m4_stale_timing", "source inspection", not ((stale_nb or stale_readme) and recorded),
       notebook_says_not_recorded=stale_nb, tutorials_readme_says_not_recorded=stale_readme, release_record_has_wall_time=recorded)

# P10 KCD-m5: activity summary embedded in the evaluation report (rerun staleness)
stages = (WT / "tools/tutorial_stages.py").read_text(encoding="utf-8")
inspected.append(WT / "tools/tutorial_stages.py")
fn = {n.name: ast.get_source_segment(stages, n) for n in ast.parse(stages).body if isinstance(n, ast.FunctionDef)}
embeds = 'run.read_state("activity.json", "evaluate")' in fn["stage_evaluate"] and '"activity": activity_summary' in fn["stage_evaluate"]
activity_overwrites = 'run.write_state("activity.json"' in fn["stage_activity"]
record("P10_KCD-m5_activity_rerun", "source inspection", not (embeds and activity_overwrites and "Try `mismatched` next" in src[22]),
       evaluate_embeds_activity=embeds, activity_rewrites_state=activity_overwrites, prose_invites_rerun="Try `mismatched` next" in src[22],
       prose_says_no_feed="does not feed into training or the final comparison" in src[22])

# P11 BYOD validation and refusal (direct execution of the carried validator on synthetic zips; no model)
def make_zip(rows, size=320, header="id,file,caption") -> Path:
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        lines = [header]
        for i, cap in rows:
            b = io.BytesIO()
            img(100 + i, size).save(b, format="PNG")
            z.writestr(f"img{i}.png", b.getvalue())
            lines.append(f"r{i},img{i}.png,{cap}" if header == "id,file,caption" else f"r{i},img{i}.png")
        z.writestr("captions.csv", "\n".join(lines) + "\n")
    p = HERE / f"_probe_{len(list(HERE.glob('_probe_*')))}.zip"
    p.write_bytes(buf.getvalue())
    return p


outcomes = {}
good = make_zip([(i, "a photo of a mug" if i < 4 else "a photo of a chair") for i in range(8)])
try:
    sp = split_dataset(load_byod_dataset(good), seed=0)
    outcomes["valid"] = {name: len(v) for name, v in sp.items()}
except Exception as exc:  # pragma: no cover
    outcomes["valid"] = f"{type(exc).__name__}: {exc}"
for label, path in (("missing_caption_column", make_zip([(i, "x") for i in range(6)], header="id,file")),
                    ("image_200px", make_zip([(i, "a photo of a mug") for i in range(6)], size=200))):
    try:
        split_dataset(load_byod_dataset(path), seed=0)
        outcomes[label] = "accepted"
    except (ValueError, TypeError) as exc:
        outcomes[label] = f"{type(exc).__name__}: {exc}"
# P13 KCD-m6: the stated BYOD minimum ("at least four images, and at least one caption with three or more images")
# against the split's real minimum (MIN_TRAIN_RECORDS training records after a 20 % / 20 % per-caption split).
boundary = {}
for label, layout in (("4 images, 1 caption", [4]), ("5 images, 1 caption", [5]), ("6 images, 2 captions x 3", [3, 3]),
                      ("6 images, 1 caption", [6]), ("8 images, 2 captions x 4", [4, 4])):
    rows, n = [], 0
    for c, k in enumerate(layout):
        for _ in range(k):
            rows.append((n, f"caption {c}"))
            n += 1
    try:
        sp = split_dataset(load_byod_dataset(make_zip(rows)), seed=0)
        boundary[label] = {"accepted": True, "splits": {name: len(v) for name, v in sp.items()}}
    except ValueError as exc:
        boundary[label] = {"accepted": False, "message": str(exc)}
meets_stated = ["4 images, 1 caption", "5 images, 1 caption", "6 images, 2 captions x 3"]
refused_despite_contract = [k for k in meets_stated if not boundary[k]["accepted"]]
record("P13_KCD-m6_byod_minimum", "direct execution (CPU, synthetic zips, validator/split only; no model)", not refused_despite_contract,
       stated_contract="at least four images, and at least one caption with three or more images", outcomes=boundary,
       meets_stated_contract_but_refused=refused_despite_contract)
for p in HERE.glob("_probe_*.zip"):
    p.unlink()
ok = isinstance(outcomes["valid"], dict) and all(isinstance(outcomes[k], str) and outcomes[k] != "accepted" for k in ("missing_caption_column", "image_200px"))
record("P11_byod_validator", "direct execution (CPU, synthetic zips, validator only; no model)", ok, outcomes=outcomes)

# P12 repository static gates
gates = {}
for name, cmd in (("pytest", [GATE_PY, "-m", "pytest", "-q", "-p", "no:cacheprovider"]),
                  ("validate_release_assets", [GATE_PY, "tools/validate_release_assets.py"]),
                  ("build_notebook_check", [GATE_PY, "tools/build_notebook.py", "--check"])):
    proc = subprocess.run(cmd, cwd=WT, capture_output=True, text=True, env={**__import__("os").environ, "PYTHONPATH": str(WT / "src")}, timeout=900)
    tail = [ln for ln in (proc.stdout + proc.stderr).splitlines() if ln.strip()][-2:]
    gates[name] = {"exit": proc.returncode, "tail": tail}
record("P12_static_gates", "direct execution (static/offline; REL8: not execution evidence)", all(g["exit"] == 0 for g in gates.values()), gates=gates)

(HERE / "results.json").write_text(json.dumps(results, indent=2), encoding="utf-8")
manifest = {}
for p in sorted(set(inspected)):
    rel = str(p.relative_to(WT)) if str(p).startswith(str(WT)) else str(p.relative_to(EVID.parent)) if str(p).startswith(str(EVID.parent)) else str(p)
    manifest[rel.replace("\\", "/")] = hashlib.sha256(p.read_bytes()).hexdigest()
(HERE / "source_manifest.json").write_text(json.dumps({"worktree_head": subprocess.run(["git", "-C", str(WT), "rev-parse", "HEAD"], capture_output=True, text=True).stdout.strip(), "files": manifest}, indent=2), encoding="utf-8")
print("wrote", HERE / "results.json")
